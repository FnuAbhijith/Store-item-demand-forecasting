import os, json, joblib, numpy as np

def model_fn(model_dir):
    # Load the saved sklearn model/pipeline from the model directory
    return joblib.load(os.path.join(model_dir, "model.joblib"))

def input_fn(request_body, request_content_type):
    # Accept JSON: {"features":[...]} for a single row OR [[...], [...]] for batch
    if request_content_type == "application/json":
        data = json.loads(request_body)
        if isinstance(data, dict) and "features" in data:
            X = np.array(data["features"], dtype=float)
            if X.ndim == 1:
                X = X.reshape(1, -1)
            return X
        elif isinstance(data, list):
            return np.array(data, dtype=float)
    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    pred = model.predict(input_data)
    out = {"prediction": pred.tolist()}
    if hasattr(model, "predict_proba"):
        try:
            out["proba"] = model.predict_proba(input_data).tolist()
        except Exception:
            out["proba"] = None
    return out

def output_fn(prediction_output, accept):
    return json.dumps(prediction_output), "application/json"
